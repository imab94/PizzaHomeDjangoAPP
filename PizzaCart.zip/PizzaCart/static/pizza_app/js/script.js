let itemsArray = [];
function get_pizza_name(pizza_name, pizza_id) {

    let badgeColor;

    if ($("#vegbadges_" + pizza_id).length > 0) {
        badgeColor = "veg";
    } else {
        badgeColor = "nonveg";
    }

    // Get the selected option based on the veg or non-veg status
    let selectedOption;

    if (badgeColor === "veg") {
        selectedOption = $("#vegpizzaOptions_" + pizza_id).val();
    } else {
        selectedOption = $("#nonvegpizzaOptions_" + pizza_id).val();
    }
    // console.log("pizza name---",pizza_name);
    //console.log("Selected Option: ", selectedOption);
    // console.log("Pizza is: ", badgeColor === "veg" ? "Veg" : "Non-Veg");
    let pizzaDetails = {
        pizzaName: pizza_name,
        selectedOption: selectedOption,
        badgeColor: badgeColor,
    };
    itemsArray.push(pizzaDetails);
    //console.log(itemsArray);
    updateCartCount();
    localStorage.setItem('pizzasArrayData', JSON.stringify(itemsArray));
}

function add_to_cart(item_name, item_id, item_price) {
    let badgeColor;
    if ($("#itembadges_" + item_id).length > 0) {
        badgeColor = "veg";
    } else {
        badgeColor = "nonveg";
    }
    let itemsDetails = {
        itemName: item_name,
        badgeColor: badgeColor,
        Price: item_price,
    };
    itemsArray.push(itemsDetails);
    //console.log(itemsArray);
    updateCartCount();
    localStorage.setItem('pizzasArrayData', JSON.stringify(itemsArray));
}

// Function to update the cart count and store it in local storage
function updateCartCount() {
    let cartCount = itemsArray.length;
    localStorage.setItem('cartCount', cartCount);
    displayCartCount();
}


// Function to get the cart count from local storage and display it in the cart navbar
function displayCartCount() {
    let cartCount = localStorage.getItem('cartCount');
    if (cartCount) {
        let cartLink = document.getElementById('updateCart');
        cartLink.innerHTML = `<i class="fa fa-shopping-cart"></i><sup> ${cartCount}</sup> `;
    }


}





