def user_authentication_status(request):
    f_name = ''
    l_name = ''
    is_authenticated = request.user.is_authenticated
    if is_authenticated and request.user != None:
        name = str(request.user)
        full_name = name.split(' ')
        f_name = full_name[0]
        l_name = full_name[1]
    return {'is_authenticated': is_authenticated,'f_name': f_name,'l_name': l_name}
