def user_authentication_status(request):
    is_authenticated = request.user.is_authenticated
    return {'is_authenticated': is_authenticated}
