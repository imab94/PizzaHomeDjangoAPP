from django.contrib import admin
from .models import (CrousalMedia,
                     Topping,Pizza,
                     Size,
                     Drinks,
                     GarlicBread,
                     Pasta,
                     FrenchFries,
                     CustomUser,
                     CartItem,
                     ContactMessage
                     )

# Register your models here.
admin.site.register(CrousalMedia)
admin.site.register(Topping)
admin.site.register(Pizza)
admin.site.register(Size)
admin.site.register(Drinks)
admin.site.register(GarlicBread)
admin.site.register(Pasta)
admin.site.register(FrenchFries)
admin.site.register(CustomUser)
admin.site.register(CartItem)

class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('user', 'date_sent')
    list_filter = ('user',)
    
admin.site.register(ContactMessage,ContactMessageAdmin)