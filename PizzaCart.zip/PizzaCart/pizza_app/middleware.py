# Create a new middleware file, e.g., middleware.py in your app directory.

from django.contrib.auth import get_user
from django.utils import timezone

class CheckUserMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.user = get_user(request)
        response = self.get_response(request)
        return response


# class SessionStartMiddleware:
#     def __init__(self, get_response):
#         self.get_response = get_response

#     def __call__(self, request):
#         if not request.session.get('_session_start'):
#             request.session['_session_start'] = timezone.now()

#         response = self.get_response(request)
#         return response
