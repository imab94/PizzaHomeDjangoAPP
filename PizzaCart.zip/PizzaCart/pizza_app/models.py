from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import Group, Permission  

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.utils import timezone
from django.contrib.auth import get_user_model

# Create your models here.

class CrousalMedia(models.Model):
    name= models.CharField(max_length=100,blank=True)
    image = models.ImageField(upload_to='pizza_app/images', default="")
    def __str__(self):
        return str(self.name)

class Topping(models.Model):
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=5, decimal_places=2)

    def __str__(self):
        return self.name


class Pizza(models.Model):
    CATEGORY_CHOICES = [
        ('VEG', 'Veg'),
        ('NON_VEG', 'Non-Veg'),
    ]

    # user = models.ForeignKey(User, on_delete=models.CASCADE)
    name= models.CharField(max_length=100,blank=True)
    image = models.ImageField(upload_to='snippets/images', default="")
    description = models.CharField(max_length=200,blank=True)
    # size = models.CharField(choices=SIZE_CHOICES, max_length=7)
    category = models.CharField(choices=CATEGORY_CHOICES, max_length=7)
    # toppings = models.ManyToManyField(Topping, related_name='pizzas', blank=True)

    def __str__(self):
        return self.name

class Size(models.Model):
    pizza = models.ForeignKey(Pizza, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    
    def __str__(self):
        return self.name
    

class GarlicBread(models.Model):
    garlic_bread_name = models.CharField(max_length=100)
    description = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    image = models.ImageField(upload_to='garlicBread/images', default=False, blank=False)
    
    def __str__(self):
        return self.garlic_bread_name
    
class Drinks(models.Model):
    drink_name = models.CharField(max_length=100)
    description = models.CharField(max_length=255,blank=True)
    image = models.ImageField(upload_to='Drinks/images', default=False, blank=False)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    
    def __str__(self):
        return self.drink_name
    
class Pasta(models.Model):
    pasta_name = models.CharField(max_length=100)
    description = models.CharField(max_length=255,blank=True)
    image = models.ImageField(upload_to='Pasta/images', default=False, blank=False)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    
    def __str__(self):
        return self.pasta_name
    

class FrenchFries(models.Model):
    frenchfries_name = models.CharField(max_length=100)
    description = models.CharField(max_length=255,blank=True)
    image = models.ImageField(upload_to='FrenchFries/images', default=False, blank=False)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    
    def __str__(self):
        return self.frenchfries_name
    
    
# create a custom user for login using Mobile Number...

class CustomUserManager(BaseUserManager):
    def create_user(self, name, email, mobile_number, password=None, **extra_fields):
        if not mobile_number:
            raise ValueError('The Mobile Number field must be set')
        email = self.normalize_email(email)
        user = self.model(name=name, email=email, mobile_number=mobile_number, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, name, email, mobile_number, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self.create_user(name, email, mobile_number, password, **extra_fields)

class CustomUser(AbstractBaseUser, PermissionsMixin):
    name = models.CharField(max_length=255)
    profile_picture = models.ImageField(upload_to='profile_picture',blank=True)
    email = models.EmailField(max_length=255, unique=True)
    mobile_number = models.CharField(max_length=15, unique=True)
    address = models.CharField(max_length=255,default='',blank=False)
    address_optional = models.CharField(max_length=255,default='',blank=False)
    pincode = models.CharField(max_length=10,default='',blank=False)
    country = models.CharField(max_length=100,default='',blank=False)
    city = models.CharField(max_length=100,default='',blank=False)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    objects = CustomUserManager()

    USERNAME_FIELD = 'mobile_number'
    REQUIRED_FIELDS = ['name', 'email']

    def __str__(self):
        return self.name

    groups = models.ManyToManyField(Group, verbose_name='Groups', blank=True, related_name='custom_users')
    user_permissions = models.ManyToManyField(Permission, verbose_name='User Permissions', blank=True, related_name='custom_users')

class CartItem(models.Model):
    user = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)
    item_name = models.CharField(max_length=255)
    quantity = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.item_name
    

class ContactMessage(models.Model):
    user = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)
    message = models.TextField()
    date_sent = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Message from {self.user.email}"
    