import pyotp
from datetime import datetime,timedelta
from twilio.rest import Client

def otp_generation(request):
    totp = pyotp.TOTP(pyotp.random_base32(),interval=60)
    otp = totp.now()
    request.session['otp_secret_key'] = totp.secret
    validate_date = datetime.now() + timedelta(minutes=1)
    request.session['otp_valid_date'] = str(validate_date)
    # account_sid = 'ACc013ad939c11202bbc129b7da4c753e4'
    # auth_token = '3911bde3c946d0be6652203a437b63f9'
    # client = Client(account_sid, auth_token)
    # message = client.messages.create(
    # from_='+14242964252',
    # body=f'your one time password (OTP) is: {otp}',
    # to='+917078337290'
    # )
    print(f"your OTP is: {otp}")
    
    
