from django.shortcuts import render,redirect,get_object_or_404
from .models import Topping,Pizza,CrousalMedia,Size,GarlicBread,FrenchFries,Pasta,Drinks,ContactMessage
from django.http import JsonResponse
from .models import CustomUser
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.http import HttpResponse
import datetime
from django.contrib import messages
from .utils import otp_generation 
import pyotp


def index(request):
    images = CrousalMedia.objects.all()
    pizza = Pizza.objects.all()
    sizes = Size.objects.all()
    garlic_bread = GarlicBread.objects.all()
    french_fries = FrenchFries.objects.all()
    pasta = Pasta.objects.all()
    cold_drinks = Drinks.objects.all()
    context = {
        'images': images,
        'pizza_menu':pizza,
        'pizza_objects':sizes,
        'garlic_bread':garlic_bread,
        'french_fries':french_fries,
        'pasta':pasta,
        'cold_drinks':cold_drinks,      
    }
          
    return render(request,'pizza_app/index.html',context)


def addtocart(request):
    pizza_name = request.GET.get('pizza_name', '')
    toppings = Topping.objects.all()
    return render(request,'pizza_app/addtocart.html',{'toppings':toppings,'pizza_name':pizza_name})


def signup(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        mobile_number = request.POST.get('mobile_number')
        if name and email and mobile_number:
            user = CustomUser.objects.create_user(name=name, email=email, mobile_number=mobile_number)
            response_data = {'message': 'Signup successful'}
            return JsonResponse(response_data)
        else:
            response_data = {'message': 'Invalid data'}
            return JsonResponse(response_data, status=400)  # Return a 400 Bad Request status


def send_otp(request):
    if request.method =="POST":
        otp = int(request.POST['combined_otp'])
        user_id =  request.session.get('user_id')
        user = CustomUser.objects.get(id=user_id)
        otp_secret = request.session['otp_secret_key']
        otp_valid_until = request.session['otp_valid_date']   
        if otp_secret and otp_valid_until is not None:
            valid_until = datetime.datetime.fromisoformat(otp_valid_until)
            if valid_until > datetime.datetime.now():
                totp = pyotp.TOTP(otp_secret,interval=60)
                if totp.verify(otp):
                    login(request,user)
                    del request.session['otp_secret_key']
                    del request.session['otp_valid_date']            
                    return redirect('indexpage') 
                else:
                    response_data = {'message': 'Login failed: invalid Otp', 'is_authenticated': False}
                    return JsonResponse(response_data, status=400)
            else:
                response_data = {'message': 'Otp Expired', 'is_authenticated': False}
                return JsonResponse(response_data, status=400)
        else:
            response_data = {'message': 'Otp is mandatory', 'is_authenticated': False}
            return JsonResponse(response_data, status=400)


def otp(request):
    if request.method == 'GET':
        return render(request, 'pizza_app/otp.html')
    
    
def user_login(request):
    if request.method == 'POST':
        mobile_number = str(request.POST.get('mobile_number'))
        mobile_number = int(mobile_number.lstrip('0'))
        user  = CustomUser.objects.get(mobile_number=mobile_number)
        if user is not None:
            # login(request, user)
            request.session['user_id'] = user.id
            otp_generation(request)
            request.session['_session_start'] = timezone.now().strftime('%Y-%m-%d %H:%M:%S.%f%z')
            request.session['is_authenticated'] = True
            request.session['profile_display'] = True
            response_data = {'message': 'Login successful', 'is_authenticated': False}
            return JsonResponse(response_data)
        else:
            response_data = {'message': 'Login failed: Invalid mobile number', 'is_authenticated': False}
            return JsonResponse(response_data, status=400)
        
    return HttpResponse("<h2>Invalid request method</h2>", status=405)


def user_logout(request):
    if request.user.is_authenticated:
        request.session['is_authenticated'] = False
        request.session['profile_display'] = False
        logout(request)
        return redirect('indexpage')
    return redirect('indexpage')
    
   
@login_required 
def user_profile(request):
    user = request.user
    context = {
        'user': user,
    }
    return render(request, 'pizza_app/user_profile.html',context)

  
@login_required     
def billingDataSubmission(request): 
    if request.method == 'POST':
        form_data = request.POST
        first_name = form_data.get('firstName')
        last_name = form_data.get('lastName')
        email = form_data.get('email')
        address = form_data.get('address')
        address2 = form_data.get('address2')
        country = form_data.get('country')
        payment_method = form_data.get('paymentMethod')

        if payment_method == 'UPI':
            upi_id = form_data.get('upiId')
            print("UPI ID:", upi_id)
        else:
            cc_name = form_data.get('ccName')
            cc_number = form_data.get('ccNumber')
            cc_expiration = form_data.get('ccExpiration')
            cc_cvv = form_data.get('ccCvv')
            
        cart_items = []
        for key, value in request.POST.items():
            if key.startswith('cartItems['):
                index = key.split('[')[1].split(']')[0]                
                item = cart_items[int(index)] if int(index) < len(cart_items) else {}
                if key.endswith('[id]'):
                    item['id'] = value
                elif key.endswith('[name]'):
                    item['name'] = value
                elif key.endswith('[price]'):
                    item['price'] = value
                if int(index) == len(cart_items):
                    cart_items.append(item)
        total_amount = request.POST.get("totalAmount")
        return JsonResponse({'message': 'Payment data received and processed.'})
    return JsonResponse({'message': 'Invalid request method.'})


def check_session_expiration(request):
    # Check if the session has expired (5 minutes in this case)
    session_start_str = request.session.get('_session_start')

    if session_start_str is not None:
        session_start = datetime.datetime.strptime(session_start_str, '%Y-%m-%d %H:%M:%S.%f%z')
        if (timezone.now() - session_start).total_seconds() >= 900:
            logout(request) 
            return JsonResponse({'session_expired': True}) 
        else:
            return JsonResponse({'session_expired': False})  
        
    return JsonResponse({'session_expired': False}) 


def update_profile(request):
    if request.method == 'POST':
        user = request.user
        user.address = request.POST.get('address')
        user.address_optional = request.POST.get('address2')
        user.pincode = request.POST.get('pincode')
        user.country = request.POST.get('country')
        user.state = request.POST.get('city')
        profile_pic = request.FILES.get('profile-pic')
        if profile_pic:
            user.profile_picture = profile_pic
        user.save()
        messages.success(request, 'Profile updated successfully')
        return redirect('user_profile') 

    return render(request, 'pizza_app/index.html')


@login_required
def contactform(request):
    if request.method == 'POST':
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        message = request.POST.get('message', '')

        if not name or not email or not message:
            response_data = {'status': 'error', 'message': 'Please fill in all required fields'}
        else:
            # Check if the authenticated user has the specified email ID
            if request.user.email == email:
                # If the email matches, save the message
                ContactMessage.objects.create(user=request.user, message=message)
                response_data = {'status': 'success', 'message': 'Message sent successfully'}
            else:
                response_data = {'status': 'error', 'message': 'Invalid email address'}

        return JsonResponse(response_data)
