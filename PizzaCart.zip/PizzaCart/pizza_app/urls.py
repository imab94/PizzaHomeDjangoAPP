from django.urls import path
from . import views
urlpatterns = [
    path("",views.index,name="indexpage"),
    path("addtocart/",views.addtocart,name="addtocart"),
    path('billing_data_submission/', views.billingDataSubmission, name='billing_data_submission'),
    path('signup/',views.signup,name='signup'),
    path('user_login/',views.user_login,name='user_login'),
    path('user_logout/',views.user_logout,name='user_logout'),
    path('user_profile/',views.user_profile,name='user_profile'),
    path('check_session_expiration/', views.check_session_expiration, name='check_session_expiration'),
    path('update_profile/', views.update_profile, name='update_profile'),
    path('contactform/', views.contactform, name='contactform'),


]